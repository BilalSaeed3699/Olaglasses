﻿using Olaglasses.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Olaglasses.Controllers
{
    public class ProductsController : Controller
    {
        private OlaGlassesEntities dbEntities = new OlaGlassesEntities();
        public ActionResult Product_Details(int? Productid)
        {
            try
            {
                //Get userid from session
                int Userid = 0;

                
                Userid = Convert.ToInt32(Session["UserID"]);
                ViewBag.Isfav = dbEntities.tblFavourites.Where(x => x.ProductID == Productid && x.UserID == Userid).FirstOrDefault();
                ViewBag.Reviewslist = dbEntities.tblReviews.Where(a => a.GlassID == Productid).ToList();
                ViewBag.Reviewscount = dbEntities.tblReviews.Where(a => a.GlassID == Productid).Count();
                ViewBag.Reviewsimagescount = dbEntities.tblReviews.Where(a => a.GlassID == Productid && a.ReviewImage != null).Count();

                var RatingSum = dbEntities.tblReviews.Where(a => a.GlassID == Productid).Select(a => a.Rating).Sum();
                var RatingCount = dbEntities.tblReviews.Where(a => a.GlassID == Productid).Count();
                RatingCount = RatingCount * 5;

                int AverageRating = 0;
                AverageRating = Convert.ToInt32((RatingSum * 5) / RatingCount);
                ViewBag.AverageRating = AverageRating;

                ViewBag.ReviewsLike = dbEntities.tblReviewLikes.Where(a => a.UserID == Userid && a.Productid == Productid).ToList();



                tblProduct product = dbEntities.tblProducts.Find(Productid);
                if (product.ProductCategory == "Accessory")
                {
                    ViewBag.Variation = dbEntities.tblglassPictures.Where(x => x.glassID == Productid).ToList();
                }
                else
                {
                    ViewBag.Variation = dbEntities.tblVariations.Where(x => x.ProductID == Productid).ToList();
                }
                
                Userid = Convert.ToInt32(Session["UserID"]);
                ViewBag.ProductList = dbEntities.Sp_Get_Product_List(Userid, "").ToList();

                ViewBag.ClientReviews = dbEntities.Sp_Get_Five_Reviews().ToList();
                return View(product);
            }
            catch (Exception ex)
            {

            }
            return View();
        }

        public ActionResult ProductFavourite(int? id = 0)
        {
            try
            {
                int UserID = 0;
                UserID = Convert.ToInt32(Session["UserID"]);
                if (UserID != 0)
                {
                    var ReviewLikeExist = dbEntities.tblFavourites.Where(a => a.ProductID == id && a.UserID == UserID);

                    if (ReviewLikeExist.Count() > 0)
                    {
                        var ReviewLike = dbEntities.tblFavourites.Where(a => a.ProductID == id && a.UserID == UserID);
                        dbEntities.tblFavourites.RemoveRange(ReviewLike);
                        dbEntities.SaveChanges();
                    }
                    else { 
                    tblFavourite tbl = new tblFavourite();
                        tbl.UserID = UserID;
                        tbl.ProductID = id;
                        tbl.CreateDate = DateTime.Now;
                        dbEntities.tblFavourites.Add(tbl);
                        dbEntities.SaveChanges();

                    }
                    
                }
                return RedirectToAction("Product_Details", "Products", new { Productid = id });
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Product_Details", "Products", new { Productid = id });
        }

        public ActionResult UpdateLikes(int? ReviewID = 0, int? GlassID = 0)
        {
            try
            {
                int UserID = 0;
                UserID = Convert.ToInt32(Session["UserID"]);
                var ReviewLikeExist = dbEntities.tblReviewLikes.Where(a => a.Productid == GlassID && a.ReviewID == ReviewID);

                if (ReviewLikeExist.Count() > 0)
                {
                    var ReviewLike = dbEntities.tblReviewLikes.Where(a => a.Productid == GlassID && a.ReviewID == ReviewID);
                    dbEntities.tblReviewLikes.RemoveRange(ReviewLike);
                    dbEntities.SaveChanges();
                }
                else if (ReviewLikeExist.Count() == 0)
                {

                    tblReviewLike tbl = new tblReviewLike();
                    tbl.UserID = UserID;
                    tbl.ReviewID = ReviewID;
                    tbl.Productid = GlassID;
                    dbEntities.tblReviewLikes.Add(tbl);
                    dbEntities.SaveChanges();
                }

                return RedirectToAction("Product_Details", "Products", new { Productid = GlassID });
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Product_Details", "Products", new { Productid = GlassID });
        }

        [HttpPost]
        public ActionResult SaveReview(string UserID, string GlassID, string Rating, HttpPostedFileBase[] ReviewImage, string Review = "")
        {
            try
            {
                tblReview review = new tblReview();
                string MainRoot = "";
                review.UserID = Convert.ToInt32(UserID);
                review.GlassID = Convert.ToInt32(GlassID);
                review.Rating = Convert.ToInt32(Rating);
                review.UserName = Convert.ToString(Session["userName"]);
                review.Review = Review;
                review.CreatedDate = DateTime.Now;


                review.UserImage = Convert.ToString(Session["UserImage"]);
                //review.ReviewImage = "/ProjectImages/Variations/placeholder.jpg";
                foreach (HttpPostedFileBase image in ReviewImage)
                {

                    if (image != null)
                    {


                        var ReviewFileName = Path.GetFileName(image.FileName);
                        MainRoot = "/ProjectImages/Uploads/Reviews/" + review.UserID;

                        bool exists = System.IO.Directory.Exists(Server.MapPath(MainRoot));
                        if (!exists)
                            System.IO.Directory.CreateDirectory(Server.MapPath(MainRoot));



                        var ReviewServerFilePath = Path.Combine(Server.MapPath(MainRoot) + "\\" + ReviewFileName);

                        MainRoot = "/ProjectImages/Uploads/Reviews/" + review.UserID + "/" + ReviewFileName;

                        review.ReviewImage = MainRoot;
                        //Save Files to path
                        image.SaveAs(ReviewServerFilePath);

                    }
                }


                dbEntities.tblReviews.Add(review);
                dbEntities.SaveChanges();
                return RedirectToAction("Product_Details", "Products", new { Productid = Convert.ToInt32(GlassID) });
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Exception Occur While Saving Broker " + ex.Message;
            }

            return RedirectToAction("Product_Details", "Products", new { Productid = Convert.ToInt32(GlassID) });
        }


        public ActionResult camera()
        {
            return View();
        }
    }
}